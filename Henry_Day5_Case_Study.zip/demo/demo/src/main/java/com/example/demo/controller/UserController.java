package com.example.demo.controller;

import com.example.demo.entity.UserData;
import com.example.demo.services.UserServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class UserController {

    @Autowired
    private UserServices userService;

    @PostMapping("/api/v1/users")
    public UserData saveUser(@RequestBody UserData userdata){
        return userService.saveUser(userdata);
    }

    @GetMapping("/api/v1/users/{id}")
    public UserData getUserById(@PathVariable("id") Long userId){
        return userService.getUserById(userId);
    }

    @PutMapping("/api/v1/users/{id}")
    public UserData updateUser(@PathVariable("id") Long userId, @RequestBody UserData userdata ){
        return userService.updateUser(userId, userdata);
    }

    @DeleteMapping("/api/v1/users/{id}")
    public void deleteUserById(@PathVariable("id") Long userId) {
        userService.deleteUserById(userId);
    }

}
