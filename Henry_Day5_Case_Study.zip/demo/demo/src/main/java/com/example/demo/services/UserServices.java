package com.example.demo.services;

import com.example.demo.entity.UserData;

public interface UserServices {

    UserData saveUser(UserData userdata);

    UserData getUserById(Long userId);

    UserData updateUser(Long userId, UserData usertable);

    String deleteUserById(Long userId);

}

