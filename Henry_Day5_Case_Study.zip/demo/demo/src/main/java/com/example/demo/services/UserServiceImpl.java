package com.example.demo.services;

import com.example.demo.entity.UserData;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service

public class UserServiceImpl implements UserServices {

    private final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserData saveUser(UserData userdata) {
        logger.info("\n\n\nLog: User Details Saved!\n\n\n");
        return userRepository.save(userdata);
    }

    @Override
    public UserData getUserById(Long userId) {
        logger.info("\n\n\nLog: User Details Displayed!\n\n\n");
        return userRepository.findById(userId).get();
    }

    @Override
    public UserData updateUser(Long userId, UserData userdata) {

        UserData userdataDB = userRepository.findById(userId).get();

        if (Objects.nonNull(userdata.getUserName()) && !"".equalsIgnoreCase(userdata.getUserName())) {
            userdataDB.setUserName(userdata.getUserName());
        }

        if (Objects.nonNull(userdata.getUserPhoneNumber()) && !"".equalsIgnoreCase(userdata.getUserPhoneNumber())) {
            userdata.setUserPhoneNumber(userdata.getUserPhoneNumber());
        }

        if (Objects.nonNull(userdata.getUserEmailAddress()) && !"".equalsIgnoreCase(userdata.getUserEmailAddress())) {
            userdata.setUserEmailAddress(userdata.getUserEmailAddress());
        }

        logger.info("\n\n\nLog: User Details Updated!\n\n\n");
        return userRepository.save(userdataDB);
    }

    @Override
    public String deleteUserById(Long userId) {
        userRepository.deleteById(userId);
        logger.info("\n\n\nLog: User Details Deleted!\n\n\n");
        return("Success");
    }
}